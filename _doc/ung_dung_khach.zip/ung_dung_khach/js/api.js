const Dia_chi_Dich_vu = "http://localhost:8080";
//const Dia_chi_Dich_vu = `https://t3h-service.herokuapp.com`;


//************** Các Hàm Xử lý Đọc Xuất   ***********

//////////////// Đồng bộ - Sync 
function apiDanhsachDienthoai() {
    var Du_lieu = {}
    var Xu_ly_HTTP = new XMLHttpRequest()
    var Tham_so = `dsDienthoai`
    var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}/${Tham_so}`
    Xu_ly_HTTP.open("GET", Dia_chi_Xu_ly, false) // Đồng bộ
    Xu_ly_HTTP.send("")
    var Chuoi_JSON = Xu_ly_HTTP.responseText
    if (Chuoi_JSON != "")
        Du_lieu = JSON.parse(Chuoi_JSON)
    return Du_lieu
}

function apiCua_hang() {
    var Du_lieu = {}
    var Xu_ly_HTTP = new XMLHttpRequest()
    var Tham_so = `Cua_hang`
    var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}/${Tham_so}`
    Xu_ly_HTTP.open("GET", Dia_chi_Xu_ly, false) // Đồng bộ
    Xu_ly_HTTP.send("")
    var Chuoi_JSON = Xu_ly_HTTP.responseText
    if (Chuoi_JSON != "")
        Du_lieu = JSON.parse(Chuoi_JSON)
    return Du_lieu
}

//////////////////////////// Bất Đồng bộ - CallBack

function apiDanhsachDienthoaiCallback(Ham_sau_khi_Xu_ly) {
    var Du_lieu = {};
    var Xu_ly_HTTP = new XMLHttpRequest();
    Xu_ly_HTTP.onload = () => {
        var Chuoi_JSON = Xu_ly_HTTP.responseText
        if (Chuoi_JSON != "")
            Du_lieu = JSON.parse(Chuoi_JSON)
        Ham_sau_khi_Xu_ly(Du_lieu)
    }
    var Tham_so = `dsDienthoai`
    var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}/${Tham_so}`
    Xu_ly_HTTP.open("GET", Dia_chi_Xu_ly) // Bất đồng bộ
    Xu_ly_HTTP.send()
}

function apiCua_hangCallback(Ham_sau_khi_Xu_ly) {
    var Du_lieu = {};
    var Xu_ly_HTTP = new XMLHttpRequest()
    Xu_ly_HTTP.onload = () => {
        var Chuoi_JSON = Xu_ly_HTTP.responseText
        if (Chuoi_JSON != "")
            Du_lieu = JSON.parse(Chuoi_JSON)
        Ham_sau_khi_Xu_ly(Du_lieu)
    }
    var Tham_so = `Cua_hang`
    var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}/${Tham_so}` // Bất đồng bộ
    Xu_ly_HTTP.open("GET", Dia_chi_Xu_ly)
    Xu_ly_HTTP.send()
}

//////////////////////////// Promise
function apiDanhsachDienthoaiPromise() {
    return new Promise((Ket_qua, Loi) => {
        var Xu_ly_HTTP = new XMLHttpRequest()
        Xu_ly_HTTP.onload = () => {
            var Doi_tuong_Kq = JSON.parse(Xu_ly_HTTP.responseText)
            Ket_qua(Doi_tuong_Kq)
        }

        var Tham_so = `dsDienthoai`
        var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}/${Tham_so}`
        Xu_ly_HTTP.open("GET", Dia_chi_Xu_ly)
        Xu_ly_HTTP.send()
    })
}

function apiCua_hangPromise() {
    return new Promise((Ket_qua, Loi) => {
        var Xu_ly_HTTP = new XMLHttpRequest()
        Xu_ly_HTTP.onload = () => {
            var Doi_tuong_Kq = JSON.parse(Xu_ly_HTTP.responseText)
            Ket_qua(Doi_tuong_Kq)
        }

        var Tham_so = `Cua_hang`
        var Dia_chi_Xu_ly = `${Dia_chi_Dich_vu}/${Tham_so}`
        Xu_ly_HTTP.open("GET", Dia_chi_Xu_ly)
        Xu_ly_HTTP.send()
    })
}



/////////////////////////// Asyn Await

async function Khoi_Dong_Du_lieu(){
    let cuahang=await apiCua_hangPromise();
    let dsDienthoai= await apiDanhsachDienthoaiPromise()
    return {cuahang,dsDienthoai};
}


