let Du_lieu = [
    {
        "Ten": "Smart Tivi Cong Samsung 49 inch",
        "Ma_so": "TIVI_1",
        "Hinh": "TIVI_1.png",
        "Don_gia": 22900000,
        "Danh_sach_Ban_hang": [
            {
                "Ma_so": "PB_1",
                "Ngay": "2018-10-10",
                "So_luong": 2,
                "Don_gia": 22900000
            },
            {
                "Ma_so": "PB_2",
                "Ngay": "2018-10-10",
                "So_luong": 1,
                "Don_gia": 22900000
            }
        ]
    },
    {
        "Ten": "Internet Tivi Samsung 32 inch",
        "Ma_so": "TIVI_8",
        "Hinh": "TIVI_8.png",
        "Don_gia": 6890000,
        "Danh_sach_Ban_hang": []
    },
    {
        "Ten": "Internet Tivi Sony 4K 43 inch",
        "Ma_so": "TIVI_4",
        "Hinh": "TIVI_4.png",
        "Don_gia": 14500000,
        "Danh_sach_Ban_hang": []
    },
    {
        "Ten": "Internet Tivi LG 55 Inch",
        "Ma_so": "TIVI_32",
        "Hinh": "TIVI_32.png",
        "Don_gia": 11480000,
        "Danh_sach_Ban_hang": []
    },
    {
        "Ten": "TV Philips",
        "Ma_so": "TIVI_34",
        "Hinh": "TIVI_34.png",
        "Don_gia": 10420000,
        "Danh_sach_Ban_hang": []
    }
]


export { Du_lieu }