function apiDanhsachTivi(){
    let xmlHttp=new XMLHttpRequest();
    xmlHttp.open("GET","./data/dsTivi.json",false);
    xmlHttp.send();
    return xmlHttp.responseText.trim();
    
}