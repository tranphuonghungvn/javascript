
let Danh_sach_Nhom_Tivi=[
    {"Ma_so":"LG","Ten":"Tivi LG","Don_gia":500000},
    {"Ma_so":"SAMSUNG","Ten":"Tivi Samsung","Don_gia":150000},
    {"Ma_so":"SONY","Ten":"Tivi Sony","Don_gia":450000},
    {"Ma_so":"KHAC","Ten":"Tivi Khác","Don_gia":250000}
];


// Xây dựng Hàm -------------------------------------- 

function Xuat(ds) {
    ds.forEach(tv => {
        console.log(`Mã số:${tv.Ma_so},Tên:${tv.Ten},Đơn giá:${tv.Don_gia}`)
    })
    console.log('---------------------------------------------------------')
}
Xuat(Danh_sach_Nhom_Tivi);
// Sắp xếp số: Đon giá Giảm

// Danh_sach_Nhom_Tivi.sort((a,b)=>{
//     return Number(b.Don_gia)-Number(a.Don_gia);
// })

// Sắp xếp Chuỗi Tăng
// Danh_sach_Nhom_Tivi.sort((a, b) => a.Ma_so.localeCompare(b.Ma_so))
// Xuat(Danh_sach_Nhom_Tivi)
// Thêm 

// let Tivi={
//     "Ma_so":"TOSHIBA","Ten":"Tivi TOSHIBA","Don_gia":1500000
// }
// Danh_sach_Nhom_Tivi.push(Tivi);
// Xuat(Danh_sach_Nhom_Tivi);
// find
// var gt='lg';
// let Kqtim=Danh_sach_Nhom_Tivi.find(x=>x.Ma_so.toLowerCase()==gt.toLowerCase())
// console.log(Kqtim);

// findIndex
// let vt=Danh_sach_Nhom_Tivi.findIndex(x=>x.Ma_so=='LG')
// console.log(vt);

////////////////////////////////////////////////////////////
// let Tinh_tong=(Danh_sach)=>{
//     let kq=0
//     Danh_sach.forEach(x=>{
//         kq+=x;
//     })
//     return kq;    
// }
// let dsSo=[1,2,3,4,5]
// // Gọi Hàm 
// let kq=Tinh_tong(dsSo)
// console.log(`Tổng [ ${dsSo.join()}] là: ${kq}`)

// let masoTivi = `LG`
// let tenTivi = ``
// switch (masoTivi) {
//     case "LG":
//         tenTivi = `Tivi LG`
//         break
//     case "SAMSUNG":
//         tenTivi = `Tivi Samsung`
//         break
//     case "SONY":
//         tenTivi = `Tivi Sony`
//         break
//     case "KHAC":
//         tenTivi = `Tivi Khác`
//         break
// }
// console.log(`Tên: ${tenTivi}`)

// let diemTb=6.5
// let xetKq=''
// if(diemTb>=5){
//     xetKq='Đậu'
// }else{
//     xetKq='Rớt'
// }
//console.log(`Kết quả cuối năm: ${xetKq}`)

// Xóa
// var gtTim='samsung';
// let chiso=Danh_sach_Nhom_Tivi.findIndex(x=>x.Ma_so.toLowerCase()==gtTim.toLowerCase())
// if(chiso!=-1){
//     Danh_sach_Nhom_Tivi.splice(chiso,1);
// }

// Danh_sach_Nhom_Tivi.forEach(tv => {
//     console.log(`${tv.Ma_so} - ${tv.Don_gia}`)
// })










// Lọc 

// var gtTim='s'
// var dsLoc=Danh_sach_Nhom_Tivi.filter(x => x.Ten.toLowerCase().includes(gtTim.toLowerCase()))
// if(dsLoc.length>0){
//     console.log(dsLoc)
// }else{
//     console.log('Không tìm thấy')
// }

// Xóa phần tử cuối
//Danh_sach_Nhom_Tivi.pop()
// Xóa phần tử đầu
//Danh_sach_Nhom_Tivi.shift()


// Xóa giá trị biết trước

// var gt='LG';
// var vt=Danh_sach_Nhom_Tivi.findIndex(x=>x.Ma_so.toLowerCase()==gt.toLowerCase());
// if(vt!=-1){
//     Danh_sach_Nhom_Tivi.splice(vt,1);
// }

// console.log(Danh_sach_Nhom_Tivi.length);
//////////////////////////////////////////////////////////////////////
/*
// Tính tổng Đơn giá cho tất cả các tivi  
let tongDongia=Danh_sach_Nhom_Tivi.reduce((tong,Tivi)=>{
    tong+=Tivi.Don_gia
    return tong
},0)
console.log(`Tổng Đơn giá: ${tongDongia}`)
*/



