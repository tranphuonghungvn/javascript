let db = `javaScriptDB`;
let objStore1 = `Dien_thoai`;
let objStore2 = `Tivi`;
let dbPromise


function checkIndexedDb(callback) {
    let dbExists = true;
    let request = window.indexedDB.open(db);
    request.onupgradeneeded = function (e) {
        e.target.transaction.abort();
        dbExists = false;
        callback(dbExists);    
    }
    
}




function Tao_Co_so_Du_lieu_indexedDB() {
    dbPromise = idb.open(db, 1, upgradeDB => {
        if (!upgradeDB.objectStoreNames.contains(objStore1)) {
            upgradeDB.createObjectStore(objStore1);
        }
        if (!upgradeDB.objectStoreNames.contains(objStore2)) {
            upgradeDB.createObjectStore(objStore2);
        }


    });
}

function Xoa_Co_so_Du_lieu_indexedDB() {
    dbPromise = idb.delete(db);
}


function Tao_Du_lieu_indexedDB_Dienthoai(Du_lieu) {
    Du_lieu.forEach(Dien_thoai => {
        idbDienthoai.set(Dien_thoai.Ma_so, Dien_thoai)
    })
}
function Tao_Du_lieu_indexedDB_Tivi(Du_lieu) {
    Du_lieu.forEach(Tivi => {
        idbTivi.set(Tivi.Ma_so, Tivi)
    })
}



idbDienthoai = {
    get(key) {
        return dbPromise.then(db => {
            return db.transaction(objStore1)
                .objectStore(objStore1).get(key);
        });
    },
    set(key, val) {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore1, 'readwrite');
            tx.objectStore(objStore1).put(val, key);
            return tx.complete;
        });
    },
    delete(key) {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore1, 'readwrite');
            tx.objectStore(objStore1).delete(key);
            return tx.complete;
        });
    },
    clear() {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore1, 'readwrite');
            tx.objectStore(objStore1).clear();
            return tx.complete;
        });
    },
    keys() {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore1);
            const keys = [];
            const store = tx.objectStore(objStore1);
            // This would be store.getAllKeys(), but it isn't supported by Edge or Safari.
            // openKeyCursor isn't supported by Safari, so we fall back
            (store.iterateKeyCursor || store.iterateCursor).call(store, cursor => {
                if (!cursor) return;
                keys.push(cursor.key);
                cursor.continue();
            });

            return tx.complete.then(() => keys);
        });
    },
    getAll() {
        return dbPromise.then(db => {
            var tx = db.transaction(objStore1, 'readonly');
            var store = tx.objectStore(objStore1);
            return store.getAll();
        });
    }

};

const idbTivi = {
    get(key) {
        return dbPromise.then(db => {
            return db.transaction(objStore2)
                .objectStore(objStore2).get(key);
        });
    },
    set(key, val) {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore2, 'readwrite');
            tx.objectStore(objStore2).put(val, key);
            return tx.complete;
        });
    },
    delete(key) {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore2, 'readwrite');
            tx.objectStore(objStore2).delete(key);
            return tx.complete;
        });
    },
    clear() {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore2, 'readwrite');
            tx.objectStore(objStore2).clear();
            return tx.complete;
        });
    },
    keys() {
        return dbPromise.then(db => {
            const tx = db.transaction(objStore2);
            const keys = [];
            const store = tx.objectStore(objStore2);
            // This would be store.getAllKeys(), but it isn't supported by Edge or Safari.
            // openKeyCursor isn't supported by Safari, so we fall back
            (store.iterateKeyCursor || store.iterateCursor).call(store, cursor => {
                if (!cursor) return;
                keys.push(cursor.key);
                cursor.continue();
            });

            return tx.complete.then(() => keys);
        });
    },
    getAll() {
        return dbPromise.then(db => {
            var tx = db.transaction(objStore2, 'readonly');
            var store = tx.objectStore(objStore2);
            return store.getAll();
        });
    }

};



