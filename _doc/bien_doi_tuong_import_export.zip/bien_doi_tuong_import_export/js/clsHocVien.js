import {apiReadFile,TITLE} from './api.js';
class Hoc_Vien{
    constructor(_maso,_ten,_phai,_diemth,_diemlt,_diemqt){
        this.MaSo=_maso
        this.HoTen=_ten
        this.Phai=_phai
        this.DiemTH=_diemth
        this.DiemLT=_diemlt
        this.DiemQT=_diemqt
    }
    Diem(){
        return (this.DiemLT+this.DiemTH+this.DiemQT)/3
    }
    gioitinh(){
        return (this.Phai)?"Nam":"Nữ"
    }
    Xuat_Thong_tin(the_hien){
        let html=`
        <h4>${TITLE}</h4>
        <h2>${this.MaSo}</h2>
        <h2>${this.HoTen}</h2>
        <h2>${this.gioitinh()}</h2>
        <h2>Điểm Thực Hành:${this.DiemTH}</h2>
        <h2>Điểm Lý Thuyết:${this.DiemLT}</h2>
        <h2>Điểm Chuyên Cần:${this.DiemQT}</h2>
        <h2>Điểm:${this.Diem()}</h2>

        `
        //return html;
        the_hien.innerHTML=html;
    }

}

export {Hoc_Vien,apiReadFile}