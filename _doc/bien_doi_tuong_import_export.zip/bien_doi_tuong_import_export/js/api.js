function apiReadFile(path){
    let http=new XMLHttpRequest();
    http.open("GET",path,false) // Sync
    http.send();
    let strJson=http.responseText; 
    return strJson;
}
export const TITLE='Import Export JS'
export {apiReadFile}