const http = require("http");
const port=8080;
const fs =require("fs");

const dich_vu =http.createServer((req,res)=>{
    let method=req.method;
    let url=req.url;
    let kq=`Welcome Server Nodejs - Method: ${method} - Url: ${url} `;
    //res.end(kq);
    if(method=="GET"){
        if(url=="/dsDienthoai"){
            kq= fs.readFileSync("./data/Dien_thoai.json","utf8") ;
            res.end(kq);
        }else if(url=="/dsNguoidung"){
            kq=`Danh sách Người dùng`;
            res.end(kq);
        }else{
            kq=`Chưa xét url:${url}`;
            res.end(kq);
        }
    }else if(method=="POST"){
        let noi_dung_nhan = ``
        req.on("data", function (data) {
            noi_dung_nhan += data
        })
        if (url == "/ThemNguoidung") {
            req.on("end", function () {
                res.end(noi_dung_nhan)
            })
        }else if(url=="/SuaNguoidung"){
            req.on("end", function () {
                res.end(noi_dung_nhan)
            })
        }else if(url=="/XoaNguoidung"){
            req.on("end", function () {
                res.end(noi_dung_nhan)
            })
        }else{
            req.on("end", function () {
                let msg=`aaa`
                res.end(msg)
            })
        }

    }else{
        kq=`Dịch vụ không xét phương thức: ${method}`
        res.end(kq);
    }
})

dich_vu.listen(port,
    console.log(`Dịch vụ thực thi tại địa chỉ: http://localhost:${port}`)
)