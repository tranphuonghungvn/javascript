const http = require("http");
const port = normalizePort(process.env.PORT || 8080); // b1
const fs = require("fs");

//Khoi tao thu vien Mongo
const mongoDB = require("mongodb");
const mongoClient = mongoDB.MongoClient;
const uri = "mongodb+srv://DbTrucNguyen:dbtrucnguyen@cluster0.834lr.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

const dbName = 'QL_DIENTHOAI';


const dich_vu = http.createServer((req, res) => {
    let method = req.method;
    let url = req.url;
    let kq = `Welcome Server Nodejs - Method: ${method} - Url: ${url} `;
    // b2
    res.setHeader("Access-Control-Allow-Origin", '*')
    res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    if (method == "GET") {
        if (url == "/dsDienthoai") {
            let collectionName = "Dien_thoai";
            getAllCollection(collectionName).then(result => {
                res.end(JSON.stringify(result));
                
            })

        } else if (url == "/dsNguoidung") {
            let collectionName = "Nguoi_dung";
            getAllCollection(collectionName).then(result => {
                res.end(JSON.stringify(result));
            })
        } else if (url == "/dsMathang") {
            let collectionName = "Mat_hang";
            getAllCollection(collectionName).then(result => {
                res.end(JSON.stringify(result));
            })
        } else if (url == "/dsTivi") {
            let collectionName = "Tivi";
            getAllCollection(collectionName).then(result => {
                res.end(JSON.stringify(result));
            })
        } else if (url == "/Cua_hang") {
            let collectionName = "Cua_hang";
            getOneCollection(collectionName).then(result => {
                res.end(JSON.stringify(result));
            })
        } else if (url.match("\.png$")) {
            var imagePath = `images/${url}`;
            if (fs.existsSync(imagePath)) {
                let fileStream = fs.createReadStream(imagePath);
                res.writeHead(200, { "Content-Type": "image/png" });
                fileStream.pipe(res);
            } else {
                imagePath = `images/noImg.png`;
                let fileStream = fs.createReadStream(imagePath);
                res.writeHead(200, { "Content-Type": "image/png" });
                fileStream.pipe(res);
            }

        } else {
            kq = `Service T3h`;
            res.end(kq);
        }
    } else if (method == "POST") {
        let noi_dung_nhan = ``
        req.on("data", function (data) {
            noi_dung_nhan += data
        })
        if (url == "/ThemNguoidung") {
            req.on("end", function () {
                res.end(noi_dung_nhan)
            })
        } else if (url == "/SuaNguoidung") {
            req.on("end", function () {
                res.end(noi_dung_nhan)
            })
        } else if (url == "/XoaNguoidung") {
            req.on("end", function () {
                res.end(noi_dung_nhan)
            })
        } else {
            req.on("end", function () {
                let msg = `aaa`
                res.end(msg)
            })
        }

    } else {
        kq = `Dịch vụ không xét phương thức: ${method}`
        res.end(kq);
    }
})

dich_vu.listen(port,
    console.log(`Dịch vụ thực thi tại địa chỉ: http://localhost:${port}`)
)
// b3
dich_vu.on('error', onError);
dich_vu.on('listening', onListening);

/**
 * Normalize a port into a number, string, or false.
 */

function normalizePort(val) {
    var port = parseInt(val, 10);

    if (isNaN(port)) {
        // named pipe
        return val;
    }

    if (port >= 0) {
        // port number
        return port;
    }

    return false;
}

/**
 * Event listener for HTTP server "error" event.
 */

function onError(error) {
    if (error.syscall !== 'listen') {
        throw error;
    }

    var bind = typeof port === 'string'
        ? 'Pipe ' + port
        : 'Port ' + port;

    // handle specific listen errors with friendly messages
    switch (error.code) {
        case 'EACCES':
            console.error(bind + ' requires elevated privileges');
            process.exit(1);
            break;
        case 'EADDRINUSE':
            console.error(bind + ' is already in use');
            process.exit(1);
            break;
        default:
            throw error;
    }
}

/**
 * Event listener for HTTP server "listening" event.
 */

function onListening() {
    var addr = dich_vu.address();
    var bind = typeof addr === 'string'
        ? 'pipe ' + addr
        : 'port ' + addr.port;
    console.log('Listening on ' + bind);
}


function getAllCollection(collectionName,) {
    return new Promise((resolve, reject) => {
        mongoClient.connect(uri).then(client => {
            client.db(dbName).collection(collectionName).find({}).toArray().then(result => {
                resolve(result)
                client.close()
            }).catch(err => {
                reject(err)
            })
        }).catch(err => {
            reject(err)
        })
    })

}
function getOneCollection(collectionName) {
    return new Promise((resolve, reject) => {
        mongoClient.connect(uri).then(client => {
            client.db(dbName).collection(collectionName).findOne({}).then(result => {

                resolve(result)
                client.close()
            }).catch(err => {
                reject(err)
            })
        }).catch(err => {
            reject(err)
        })
    })

}