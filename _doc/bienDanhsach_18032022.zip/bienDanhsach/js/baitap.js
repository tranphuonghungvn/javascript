/*
Thực hiện truy vấn xem thông tin

o	Tìm Tivi có mã số “TIVI_32”, thông tin trả về gồm: Tên, Mã số, Hình, Đơn giá
o	Lọc danh sách các Tivi  49 inch, thông tin trả về gồm: Tên, Mã số, Hình, Đơn giá, Danh sách bán hàng
o	Lọc danh sách các Tivi có đơn giá <= 3000000, thông tin trả về gồm: Tên, Mã số, Hình, Đơn giá. Sắp xếp theo đơn giá giảm dần 
o	Lọc danh sách các Tivi được bán trong ngày 10/10/2018 , thông tin trả về gồm: Tên, Mã số, Hình, Đơn giá, Danh sách bán hang. Sắp xếp theo tên Tivi
o	Lọc danh sách các Tivi không bán được trong ngày 10/10/2018 , thông tin trả về gồm: Tên, Mã số, Hình, Đơn giá, Danh sách bán hang. Sắp xếp tên Tivi
o	Lọc danh sách các Tivi 49 inch được bán từ ngày 10/10/2018 đến 20/10/2018, thông tin trả về gồm: Tên, Mã số, Hình, Đơn giá, Danh sách bán hang. Sắp xếp theo mã số Tivi
o	Tính tổng số lượng bán của các Tivi trong ngày 10/10/2018, thông tin gồm: Tên, Mã, Hình, Đơn giá, Tổng số lượng bán
o	Cho biết 3 Tivi có có doanh thu cao nhất trong ngày 10/10/2018

Thực hiện truy vấn cập nhật thông tin

o	Thêm mới Tivi vào trong danh sách Tivi, thông tin gồm:
		Tên: “Internet Tivi SONY Ultra HD 55 inch”
		Mã số: “TIVI_24”
		Hình: “TIVI_24.png”
		Đơn giá: 8640000
		Danh sách Bán hàng: [ ]

o	Cập nhật đơn giá Tivi có mã số “TIVI_24”  thành 8600000
o	Xóa Tivi có mã số “TIVI_24”

Xây dựng hàm

o	Xây dựng hàm Xóa Tivi trong danh sách Tivi với tham số nhận vào là Mã số Tivi cần xóa.
o	Xây dựng hàm Thêm mới Tivi vào trong danh sách Tivi với tham số nhận vào là đối tượng Tivi cần thêm.
o	Xây dựng hàm Cập nhật Đơn giá Tivi (dựa vào Mã số Tivi) trong danh sách Tivi với tham số nhận vào là đối tượng Tivi cần cập nhật.

*/

import {Du_lieu}  from '../data/dsTivi.js';
console.log(Du_lieu.length);
//XuatDanhsach(Du_lieu)
// Xây dựng Hàm xuất Mảng
// function XuatDanhsach(ds){
// 	ds.forEach(item=>{
// 		console.log(`Mã số:${item.Ma_so} - Tên:${item.Ma_so} - Đơn giá:${item.Don_gia}`);
// 	})
// 	console.log('----------------------------------------------');
// }



// 1 Tìm Tivi có mã số “TIVI_32”, thông tin trả về gồm: Tên, Mã số, Hình, Đơn giá
// let gtTim='TIVI_32';
// let tivi=Du_lieu.find(item=>item.Ma_so==gtTim);
// if(tivi){
// 	console.log(`Mã số:${tivi.Ma_so} - Tên:${tivi.Ma_so} - Đơn giá:${tivi.Don_gia}`)
// }else{
// 	console.log('Tìm không thấy');
// }



