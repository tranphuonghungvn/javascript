function apiDanhsachHocvien(){
    let xmlHttp=new XMLHttpRequest();
    xmlHttp.open("GET","./data/dsHocvien.json",false);
    xmlHttp.send();
    return JSON.parse(xmlHttp.responseText.trim()).danh_sach;
    
}